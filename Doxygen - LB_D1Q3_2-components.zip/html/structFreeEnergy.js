var structFreeEnergy =
[
    [ "freeEnergy1", "structFreeEnergy.html#a514699933186078d31788180947ce11d", null ],
    [ "freeEnergy2", "structFreeEnergy.html#ab8b55734b36d56a42ae46ee28a165213", null ],
    [ "freeEnergy3", "structFreeEnergy.html#aca8b30a2881cd5c7a8b3a66eda07b4fb", null ],
    [ "freeEnergyTotal", "structFreeEnergy.html#aae84a61ee721801957ca082684619229", null ]
];