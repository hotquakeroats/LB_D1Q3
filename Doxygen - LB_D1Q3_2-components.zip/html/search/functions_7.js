var searchData=
[
  ['laplace',['laplace',['../LB__Analyze_8c.html#ae16470dabf4e18fe9ec8b3d45833650a',1,'laplace(double *var, int i):&#160;LB_Analyze.c'],['../LB__D1Q3__2-components_8h.html#a858fd29d4a7a35f29b999223a1465378',1,'laplace(double *, int):&#160;LB_Analyze.c']]],
  ['logvdwparameters',['logVDWParameters',['../LB__D1Q3__2-components_8h.html#a8e8f25c3fc0b52545fc9356400148a7b',1,'logVDWParameters():&#160;LB_Files.c'],['../LB__Files_8c.html#a8e8f25c3fc0b52545fc9356400148a7b',1,'logVDWParameters():&#160;LB_Files.c']]]
];
