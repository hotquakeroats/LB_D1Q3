var searchData=
[
  ['freeenergy',['FreeEnergy',['../structFreeEnergy.html',1,'']]]
];
