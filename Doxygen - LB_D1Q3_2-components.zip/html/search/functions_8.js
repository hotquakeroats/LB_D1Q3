var searchData=
[
  ['main',['main',['../LB__Simulation_8c.html#a0ddf1224851353fc92bfbff6f499fa97',1,'LB_Simulation.c']]],
  ['minimizefreeenergytwocomponentsthreephases',['minimizeFreeEnergyTwoComponentsThreePhases',['../LB__Analyze_8c.html#aa378a45012001ae886c4961aeacbc67a',1,'LB_Analyze.c']]]
];
