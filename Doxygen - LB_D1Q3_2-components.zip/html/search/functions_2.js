var searchData=
[
  ['calculatechemicalpotential',['calculateChemicalPotential',['../LB__Analyze_8c.html#a6c19bf8f010e8b4896bbb3ac3e63afc8',1,'LB_Analyze.c']]],
  ['calculatefreeenergyminimumthreephasetrial',['calculateFreeEnergyMinimumThreePhaseTrial',['../LB__Analyze_8c.html#ae44e0720ae9cb3f7670a42ab20baa1a8',1,'LB_Analyze.c']]],
  ['calculatefreeenergyminimumtwophasetrial',['calculateFreeEnergyMinimumTwoPhaseTrial',['../LB__Analyze_8c.html#afdd9c40578c4d744b070e655561af48f',1,'LB_Analyze.c']]],
  ['calculatefriction',['calculateFriction',['../LB__D1Q3__2-components_8c.html#aaae91ab7a88cd57e80f21248c43df022',1,'LB_D1Q3_2-components.c']]],
  ['calculatekandsparameters',['calculateKandSParameters',['../LB__Analyze_8c.html#a297964496a7591275568386f19ac230a',1,'calculateKandSParameters():&#160;LB_Analyze.c'],['../LB__D1Q3__2-components_8h.html#a297964496a7591275568386f19ac230a',1,'calculateKandSParameters():&#160;LB_Analyze.c']]],
  ['calculatelbchemicalpotentials',['calculateLBChemicalPotentials',['../LB__D1Q3__2-components_8c.html#a68f301f5147a93266f81518cd360f166',1,'LB_D1Q3_2-components.c']]],
  ['calculatelbpressure',['calculateLBPressure',['../LB__D1Q3__2-components_8c.html#a15b63cdc21299654427a96b845f0d060',1,'LB_D1Q3_2-components.c']]],
  ['calculatemass',['calculateMass',['../LB__D1Q3__2-components_8c.html#aa9e1574dbfa31bcc34b45cf836227c27',1,'LB_D1Q3_2-components.c']]],
  ['calculateminimizationpath',['calculateMinimizationPath',['../LB__Analyze_8c.html#a96004407fbdcb93380f4872da84378cf',1,'calculateMinimizationPath(double rhoA, double rhoB, double *eigenvectorA, double *eigenvectorB):&#160;LB_Analyze.c'],['../LB__D1Q3__2-components_8h.html#ad1338bf064a9bdf6bdb7398835f438ff',1,'calculateMinimizationPath(double, double, double *, double *):&#160;LB_Analyze.c']]],
  ['calculatephasediagramrhoavsrhobthreephasestheoretical',['calculatePhaseDiagramRhoAVsRhoBThreePhasesTheoretical',['../LB__Analyze_8c.html#aa7e30ae5250f83e85fa92e4de76be96d',1,'calculatePhaseDiagramRhoAVsRhoBThreePhasesTheoretical():&#160;LB_Analyze.c'],['../LB__D1Q3__2-components_8h.html#aa7e30ae5250f83e85fa92e4de76be96d',1,'calculatePhaseDiagramRhoAVsRhoBThreePhasesTheoretical():&#160;LB_Analyze.c']]],
  ['calculatephasediagramrhoavsrhobtwophasestheoretical',['calculatePhaseDiagramRhoAVsRhoBTwoPhasesTheoretical',['../LB__Analyze_8c.html#ab11fbbf06bb541c7a0ec08ad968a2aa1',1,'calculatePhaseDiagramRhoAVsRhoBTwoPhasesTheoretical():&#160;LB_Analyze.c'],['../LB__D1Q3__2-components_8h.html#ab11fbbf06bb541c7a0ec08ad968a2aa1',1,'calculatePhaseDiagramRhoAVsRhoBTwoPhasesTheoretical():&#160;LB_Analyze.c']]],
  ['calculatepressure',['calculatePressure',['../LB__Analyze_8c.html#af7cc27b765f46334a050f155d22eba2c',1,'LB_Analyze.c']]],
  ['calculatevelocities',['calculateVelocities',['../LB__D1Q3__2-components_8c.html#a52790a373fa5b810402b651de109d8ea',1,'LB_D1Q3_2-components.c']]],
  ['checkvaporphase',['checkVaporPhase',['../LB__Analyze_8c.html#a96dc509e816a1d2f1cb2030e28aafeab',1,'LB_Analyze.c']]],
  ['collisionforcingnewchemicalpotentialgradient',['collisionForcingNewChemicalPotentialGradient',['../LB__D1Q3__2-components_8c.html#a954e41fb46698cdb00db617cf14f81c5',1,'LB_D1Q3_2-components.c']]],
  ['correctexcessmomentum',['correctExcessMomentum',['../LB__D1Q3__2-components_8c.html#a012581f1cc809001dd4cee1d4c809e3c',1,'LB_D1Q3_2-components.c']]],
  ['correctvelocities',['correctVelocities',['../LB__D1Q3__2-components_8c.html#a1c8e4bc18ba357c24dfc392d420a86dd',1,'LB_D1Q3_2-components.c']]]
];
