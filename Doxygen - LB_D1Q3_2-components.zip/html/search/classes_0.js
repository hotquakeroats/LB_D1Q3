var searchData=
[
  ['binodalpoint',['BinodalPoint',['../structBinodalPoint.html',1,'']]]
];
