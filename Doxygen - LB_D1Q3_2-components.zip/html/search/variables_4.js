var searchData=
[
  ['endgammafactor',['endGammaFactor',['../LB__D1Q3__2-components_8c.html#a444540dd4a7b271c569f726cbdda9299',1,'endGammaFactor():&#160;LB_D1Q3_2-components.c'],['../LB__D1Q3__2-components_8h.html#a444540dd4a7b271c569f726cbdda9299',1,'endGammaFactor():&#160;LB_D1Q3_2-components.c']]]
];
