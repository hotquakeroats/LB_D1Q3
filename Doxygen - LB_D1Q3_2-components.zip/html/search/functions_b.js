var searchData=
[
  ['readthreephaseregioncoordinates',['readThreePhaseRegionCoordinates',['../LB__D1Q3__2-components_8h.html#a67fd1c13c2f690c479b42d9cac575e88',1,'readThreePhaseRegionCoordinates():&#160;LB_Files.c'],['../LB__Files_8c.html#a67fd1c13c2f690c479b42d9cac575e88',1,'readThreePhaseRegionCoordinates():&#160;LB_Files.c']]]
];
