var searchData=
[
  ['definethreephaseregion',['defineThreePhaseRegion',['../LB__Analyze_8c.html#a988dbd44d80aad58a56a5d958e3e19d1',1,'LB_Analyze.c']]],
  ['detecttwoorthreephaseregion',['detectTwoOrThreePhaseRegion',['../LB__Analyze_8c.html#a5faf89b76c893cd4bfe9d096c014b160',1,'LB_Analyze.c']]],
  ['determinelbmetastableresults',['determineLBMetastableResults',['../LB__Analyze_8c.html#ad7c35e81fe18e2bf2782220a3842654f',1,'LB_Analyze.c']]]
];
