var searchData=
[
  ['lambda',['lambda',['../LB__D1Q3__2-components_8c.html#a3db359547eed8cfd48ca821d95f577af',1,'lambda():&#160;LB_D1Q3_2-components.c'],['../LB__D1Q3__2-components_8h.html#a3db359547eed8cfd48ca821d95f577af',1,'lambda():&#160;LB_D1Q3_2-components.c']]],
  ['laplace',['laplace',['../LB__Analyze_8c.html#ae16470dabf4e18fe9ec8b3d45833650a',1,'laplace(double *var, int i):&#160;LB_Analyze.c'],['../LB__D1Q3__2-components_8h.html#a858fd29d4a7a35f29b999223a1465378',1,'laplace(double *, int):&#160;LB_Analyze.c']]],
  ['lb_5fanalyze_2ec',['LB_Analyze.c',['../LB__Analyze_8c.html',1,'']]],
  ['lb_5fanalyze_2ed',['LB_Analyze.d',['../LB__Analyze_8d.html',1,'']]],
  ['lb_5fd1q3_5f2_2dcomponents_2ec',['LB_D1Q3_2-components.c',['../LB__D1Q3__2-components_8c.html',1,'']]],
  ['lb_5fd1q3_5f2_2dcomponents_2ed',['LB_D1Q3_2-components.d',['../LB__D1Q3__2-components_8d.html',1,'']]],
  ['lb_5fd1q3_5f2_2dcomponents_2eh',['LB_D1Q3_2-components.h',['../LB__D1Q3__2-components_8h.html',1,'']]],
  ['lb_5ffiles_2ec',['LB_Files.c',['../LB__Files_8c.html',1,'']]],
  ['lb_5ffiles_2ed',['LB_Files.d',['../LB__Files_8d.html',1,'']]],
  ['lb_5fgui_2ec',['LB_GUI.c',['../LB__GUI_8c.html',1,'']]],
  ['lb_5fgui_2ed',['LB_GUI.d',['../LB__GUI_8d.html',1,'']]],
  ['lb_5finitialize_2ec',['LB_Initialize.c',['../LB__Initialize_8c.html',1,'']]],
  ['lb_5finitialize_2ed',['LB_Initialize.d',['../LB__Initialize_8d.html',1,'']]],
  ['lb_5fsimulation_2ec',['LB_Simulation.c',['../LB__Simulation_8c.html',1,'']]],
  ['lb_5fsimulation_2ed',['LB_Simulation.d',['../LB__Simulation_8d.html',1,'']]],
  ['logvdwparameters',['logVDWParameters',['../LB__D1Q3__2-components_8h.html#a8e8f25c3fc0b52545fc9356400148a7b',1,'logVDWParameters():&#160;LB_Files.c'],['../LB__Files_8c.html#a8e8f25c3fc0b52545fc9356400148a7b',1,'logVDWParameters():&#160;LB_Files.c']]]
];
