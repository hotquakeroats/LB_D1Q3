var searchData=
[
  ['openfile',['openFile',['../LB__D1Q3__2-components_8h.html#a72a18f5234725ab1fe6bb03e57c329be',1,'openFile(char *, char *, char *):&#160;LB_Files.c'],['../LB__Files_8c.html#abaffa1375d38bf844c37037a7db7d061',1,'openFile(char *fileName, char *extension, char *attributes):&#160;LB_Files.c']]]
];
