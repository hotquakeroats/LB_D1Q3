var searchData=
[
  ['writethreephaseregioncoordinates',['writeThreePhaseRegionCoordinates',['../LB__D1Q3__2-components_8h.html#a007a60d067bd986553f8d1afd57b5e7c',1,'writeThreePhaseRegionCoordinates():&#160;LB_Files.c'],['../LB__Files_8c.html#a007a60d067bd986553f8d1afd57b5e7c',1,'writeThreePhaseRegionCoordinates():&#160;LB_Files.c']]]
];
