var searchData=
[
  ['f1',['F1',['../LB__D1Q3__2-components_8h.html#ae671d5bac9560c5a2af987d8b7f108dd',1,'LB_D1Q3_2-components.h']]],
  ['f1_5f0',['f1_0',['../LB__D1Q3__2-components_8h.html#aa0545abcf9bda194d6bbb9880eb6278c',1,'LB_D1Q3_2-components.h']]],
  ['f1_5f1',['f1_1',['../LB__D1Q3__2-components_8h.html#ac741fea23623efc17554fe0737f990cc',1,'LB_D1Q3_2-components.h']]],
  ['f1_5f2',['f1_2',['../LB__D1Q3__2-components_8h.html#aeffb442bd0216d51c47ce5cb0752086e',1,'LB_D1Q3_2-components.h']]],
  ['f2',['F2',['../LB__D1Q3__2-components_8h.html#a4f223ffc201f6662a95ee9b91ff98d64',1,'LB_D1Q3_2-components.h']]],
  ['f2_5f0',['f2_0',['../LB__D1Q3__2-components_8h.html#a9fb262c956051d161fb72932c9e04f25',1,'LB_D1Q3_2-components.h']]],
  ['f2_5f1',['f2_1',['../LB__D1Q3__2-components_8h.html#ac7cfc0957cb16604787df408ffd732b9',1,'LB_D1Q3_2-components.h']]],
  ['f2_5f2',['f2_2',['../LB__D1Q3__2-components_8h.html#a505b3fc06831a22366b5e1dafe9d81d9',1,'LB_D1Q3_2-components.h']]],
  ['fitinterfacewidthtokappa',['fitInterfaceWidthToKappa',['../LB__D1Q3__2-components_8c.html#a1239c0db69a687395af2116a167defce',1,'fitInterfaceWidthToKappa():&#160;LB_D1Q3_2-components.c'],['../LB__D1Q3__2-components_8h.html#a1239c0db69a687395af2116a167defce',1,'fitInterfaceWidthToKappa():&#160;LB_D1Q3_2-components.c']]],
  ['freeenergy1',['freeEnergy1',['../structFreeEnergy.html#a514699933186078d31788180947ce11d',1,'FreeEnergy']]],
  ['freeenergy2',['freeEnergy2',['../structFreeEnergy.html#ab8b55734b36d56a42ae46ee28a165213',1,'FreeEnergy']]],
  ['freeenergy3',['freeEnergy3',['../structFreeEnergy.html#aca8b30a2881cd5c7a8b3a66eda07b4fb',1,'FreeEnergy']]],
  ['freeenergytotal',['freeEnergyTotal',['../structFreeEnergy.html#aae84a61ee721801957ca082684619229',1,'FreeEnergy']]],
  ['friction1',['friction1',['../LB__D1Q3__2-components_8h.html#ac9a43586e53b1460b7cc1f64f7a593b4',1,'LB_D1Q3_2-components.h']]],
  ['friction2',['friction2',['../LB__D1Q3__2-components_8h.html#a9e6e141c4034ae90e38118dd0a887b51',1,'LB_D1Q3_2-components.h']]]
];
