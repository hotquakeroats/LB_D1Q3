var searchData=
[
  ['initializeprofile',['initializeProfile',['../LB__Initialize_8c.html#a82f0ab284aaec8b942e99e47a0e09d06',1,'LB_Initialize.c']]],
  ['initializerandomcomponents',['initializeRandomComponents',['../LB__D1Q3__2-components_8c.html#ab55283b5aa1df9a1cc644fa8340b5b43',1,'initializeRandomComponents():&#160;LB_D1Q3_2-components.c'],['../LB__D1Q3__2-components_8h.html#ab55283b5aa1df9a1cc644fa8340b5b43',1,'initializeRandomComponents():&#160;LB_D1Q3_2-components.c']]],
  ['interfacewidth',['interfaceWidth',['../LB__D1Q3__2-components_8c.html#a18168c76d2095cb43fe023fcbd9701e1',1,'interfaceWidth():&#160;LB_D1Q3_2-components.c'],['../LB__D1Q3__2-components_8h.html#a18168c76d2095cb43fe023fcbd9701e1',1,'interfaceWidth():&#160;LB_D1Q3_2-components.c']]],
  ['interfacewidthforgivenkappa',['interfaceWidthForGivenKappa',['../LB__D1Q3__2-components_8c.html#accca3db5ee1ea8ba1f2615871a1521eb',1,'interfaceWidthForGivenKappa():&#160;LB_D1Q3_2-components.c'],['../LB__D1Q3__2-components_8h.html#accca3db5ee1ea8ba1f2615871a1521eb',1,'interfaceWidthForGivenKappa():&#160;LB_D1Q3_2-components.c']]],
  ['invalidfreeenergy',['invalidFreeEnergy',['../LB__D1Q3__2-components_8c.html#a20f93c3de37ab5a6507fd20733538a5a',1,'LB_D1Q3_2-components.c']]],
  ['iterations',['iterations',['../LB__D1Q3__2-components_8c.html#a1d10e252e778731e59f0f71afd7e727e',1,'iterations():&#160;LB_D1Q3_2-components.c'],['../LB__D1Q3__2-components_8h.html#a1d10e252e778731e59f0f71afd7e727e',1,'iterations():&#160;LB_D1Q3_2-components.c']]]
];
