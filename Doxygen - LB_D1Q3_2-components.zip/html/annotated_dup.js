var annotated_dup =
[
    [ "BinodalPoint", "structBinodalPoint.html", "structBinodalPoint" ],
    [ "FreeEnergy", "structFreeEnergy.html", "structFreeEnergy" ]
];