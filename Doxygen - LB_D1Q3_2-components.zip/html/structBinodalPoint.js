var structBinodalPoint =
[
    [ "rhoA", "structBinodalPoint.html#adebf1f19fb446fd844e36147387752c0", null ],
    [ "rhoB", "structBinodalPoint.html#a4c7e7a85b479644d7bab8c695416cae8", null ]
];