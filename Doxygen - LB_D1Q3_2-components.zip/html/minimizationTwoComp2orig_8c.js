var minimizationTwoComp2orig_8c =
[
    [ "F", "minimizationTwoComp2orig_8c.html#aa1903093532bb79c80f117a984c3cf2c", null ],
    [ "Minimize2", "minimizationTwoComp2orig_8c.html#a7cbadb956b003ae059e1823abc255b8c", null ],
    [ "minimize2", "minimizationTwoComp2orig_8c.html#af219a21f2370007804cf411a22690972", null ],
    [ "amm", "minimizationTwoComp2orig_8c.html#ae4c7e8b5f6c3d1da28b6f985865bd84c", null ],
    [ "anm", "minimizationTwoComp2orig_8c.html#a27fed6c6639a9ba1958b72167abd10ed", null ],
    [ "ann", "minimizationTwoComp2orig_8c.html#a4f2c1462d8158b86002cadfad4ee4e47", null ],
    [ "b", "minimizationTwoComp2orig_8c.html#a1510a66dacf9cf3586de5fc89ae2a073", null ]
];